/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import java.sql.*;
/**
 *
 * @author dell
 */
public class AddService {
    public static boolean addEmployee(String id,String name,String salary,String phone,String address){
        try{
           Connection   connection=dbconfig.Driver.getConnection();
           Statement statement=connection.createStatement();
           int addRow=statement.executeUpdate("INSERT INTO emp VALUES('"+id+"','"+name+"','"+salary+"','"+phone+"','"+address+"')");
           if(addRow>0){
               return true;
           }
        }catch (Exception e){
            e.printStackTrace();
            
        }
        return false;
        
    }
}
