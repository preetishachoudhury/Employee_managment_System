/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

/**
 *
 * @author dell
 */
import java.sql.*;
public class LoginService {
    public static boolean validUser(String id,String pass){
        try {
            Connection connection=dbconfig.Driver.getConnection();
            Statement statement=connection.createStatement();
            ResultSet resultSet=statement.executeQuery("SELECT * From admin where id = '"+id+"' AND password ='"+pass+"'");//soa db is used
            while(resultSet.next()){                                                                                       //not iter
                return true;
            }
        }
        catch(Exception e){
        }
    return false;
    }
}
