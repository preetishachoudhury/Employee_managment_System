/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

/**
 *
 * @author dell
 */
import java.sql.*;

public class ForgotPassword {

    public static boolean validId(String user_id) {
        try {
            Connection connection = dbconfig.Driver.getConnection();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select id from admin where id='" + user_id + "'");
            while (resultSet.next()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public static boolean updatePassword(String id,String password){
        try{
           Connection connection = dbconfig.Driver.getConnection();
            Statement statement = connection.createStatement();
            int updatePass=statement.executeUpdate("UPDATE admin SET password='"+password+"'WHERE id='"+id+"'");
            if(updatePass>0){
                return true;
            }
        }catch(Exception e){
            e.printStackTrace();
    }
        return false;
}
}