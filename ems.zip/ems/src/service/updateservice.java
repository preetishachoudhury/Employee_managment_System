/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import java.sql.*;

/**
 *
 * @author dell
 */
public class updateservice {
    public static boolean updateEmployeeDetails(String id,String name,String address,String salary,String phone,String add){
        try {
           Connection connection=dbconfig.Driver.getConnection();
            Statement statement=connection.createStatement();
            int updaterow=statement.executeUpdate("UPDATE emp SET e_name='"+name+"',e_salary='"+salary+"',e_phone='"+phone+"',e_address='"+address+"'WHERE e_id='"+id+"'");
            if(updaterow>0){
                return true;
            } 
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
