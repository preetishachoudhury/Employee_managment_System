/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import java.sql.*;
/**
 *
 * @author dell
 */
public class deleteservice {
    public static boolean deleteEmp(String id){
        try {
            Connection connection=dbconfig.Driver.getConnection();
            Statement statement =connection.createStatement();
            int deleterow=statement.executeUpdate("delete from emp where e_id='"+id+"'");
            if(deleterow>0){
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
}
