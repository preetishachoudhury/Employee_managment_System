/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dbconfig;

/**
 *
 * @author dell
 */
import java.sql.*;
public class Driver {
    public static Connection getConnection(){
        Connection connection=null;
        String classname="com.mysql.cj.jdbc.Driver";
        String url= "jdbc:mysql://localhost:3306/soa";
        String user="root";
        String password="preetis@123";
       try{
           Class.forName(classname);
            connection= DriverManager.getConnection(url,user,password);
       }catch (Exception e){
           e.printStackTrace();
       }
      return connection;         
    }
}
